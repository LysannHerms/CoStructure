import { useTranslation } from "react-i18next";

export default function LanguageSwitcher() {
  const { i18n } = useTranslation();
  const current = i18n.language.startsWith("de") ? "de" : "en";

  const change = (lng: "de" | "en") => {
    if (lng !== current) i18n.changeLanguage(lng);
  };

  return (
    <div role="group" aria-label="Language switch" className="inline-flex rounded-lg border">
      <button
        type="button"
        aria-pressed={current === "de"}
        onClick={() => change("de")}
        className={`px-3 py-1 ${current === "de" ? "bg-black text-white" : "hover:bg-gray-100"}`}
      >
        DE
      </button>
      <button
        type="button"
        aria-pressed={current === "en"}
        onClick={() => change("en")}
        className={`px-3 py-1 border-l ${current === "en" ? "bg-black text-white" : "hover:bg-gray-100"}`}
      >
        EN
      </button>
    </div>
  );
}
