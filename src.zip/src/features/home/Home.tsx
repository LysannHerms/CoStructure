import Section from "../../shared/ui/Section";
import Hero from "./Hero";
import Sketch from "./Sketch";
import SectionCards from "./SectionCards";
import { useTranslation } from "react-i18next";


export default function Home() {
      const { t } = useTranslation("common");
  return (
    <div>
      <Hero />
      <Section title="Projekt" subtitle={t("hero.title")}>
        <p className="max-w-2xl text-[color:var(--ink)]/75">{t("hero.ctaExplore")}
        </p>
      </Section>
      <Section title="Skizze">
        <Sketch />
      </Section>
      <Section title="Abschnitte">
        <SectionCards />
      </Section>
    </div>
  );
}
