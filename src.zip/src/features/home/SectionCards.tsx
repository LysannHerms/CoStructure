import { Link } from "react-router-dom";

const cards = [
  { title: "Map", desc: "Interaktive Stadtkarte mit wenigen, aber pointierten Orten.", to: "/map" },
  { title: "Gallery", desc: "Skizzen, Schnappschüsse, Materialsammlung.", to: "#" },
  { title: "About", desc: "Was ist CoStructure? Ansatz, Tools, Ziele.", to: "#" },
];

export default function SectionCards() {
  return (
    <div id="sections" className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {cards.map((c) => (
        <Link
          key={c.title}
          to={c.to}
          className="group rounded-2xl border border-[color:var(--line)] bg-white p-5 transition-colors hover:bg-[color:var(--rose)]/20"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-[color:var(--ink)]">{c.title}</h3>
            <span className="text-[color:var(--wine)]">→</span>
          </div>
          <p className="mt-2 text-sm text-[color:var(--ink)]/70">{c.desc}</p>
          <div className="mt-4 h-[2px] w-12 bg-[color:var(--wine)]/60 group-hover:w-20 transition-all" />
        </Link>
      ))}
    </div>
  );
}
