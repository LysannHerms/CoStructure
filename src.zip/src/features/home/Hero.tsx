import { Link } from "react-router-dom";

export default function Hero() {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-[color:var(--line)] bg-white">
      {/* zarte rosé Fläche als Grafikband */}
      <div className="absolute inset-0 pointer-events-none">
      </div>

      <div className="relative px-6 py-10 md:px-10 md:py-14">
        <div className="max-w-2xl">
          <h1 className="text-3xl md:text-4xl font-bold leading-tight text-[color:var(--ink)]">
            CoStructure
          </h1>
          <p className="mt-3 text-[color:var(--ink)]/75">
            Minimaler Architektur-Prototyp: urbane Orte, klare Formen, ruhige Flächen. React + TS + Tailwind.
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              to="/map"
              className="inline-flex items-center rounded-lg border border-[color:var(--wine)] bg-[color:var(--wine)] px-4 py-2 text-white hover:opacity-90"
            >
              Explore Map
            </Link>
            <a
              href="#sections"
              className="inline-flex items-center rounded-lg border border-[color:var(--wine)] px-4 py-2 text-[color:var(--wine)] hover:bg-[color:var(--rose)]/40"
            >
              See Sections
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
