import { Link, Outlet } from "react-router-dom";
import { useTranslation } from "react-i18next";
import SkipLink from "../shared/ui/SkipLink";
import LanguageSwitcher from "../shared/ui/LanguageSwitcher";

export default function App() {
  const { t } = useTranslation("common");
  return (
    <div className="min-h-dvh bg-white text-gray-900">
      <SkipLink />
      <header className="sticky top-0 border-b bg-white/80 backdrop-blur" role="banner">
        <div className="mx-auto max-w-5xl px-4 py-3 flex items-center justify-between">
          <div className="font-semibold text-[color:var(--wine)]" aria-label={t("brand")}>
            {t("brand")}
          </div>
          <nav aria-label="Hauptnavigation" className="hidden sm:flex gap-6 items-center">
            <Link to="/">{t("nav.home")}</Link>
            <Link to="/map">{t("nav.map")}</Link>
            <LanguageSwitcher />
          </nav>
        </div>
      </header>

      <main id="main" role="main" className="mx-auto max-w-5xl px-4 py-8">
        <Outlet />
      </main>

      <footer role="contentinfo" className="border-t">
        <div className="mx-auto max-w-5xl px-4 py-6 text-sm text-gray-500">
          {t("footer", { year: new Date().getFullYear() })}
        </div>
      </footer>
    </div>
  );
}
