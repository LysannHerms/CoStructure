import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import de from "../locales/de/common.json";
import en from "../locales/en/common.json";

const STORAGE_KEY = "locale";
const fallbackLng = "de";
const stored = (typeof window !== "undefined" && localStorage.getItem(STORAGE_KEY)) || "";
const browser = typeof navigator !== "undefined" ? navigator.language.split("-")[0] : "";
const initial = (stored || browser || fallbackLng).startsWith("de") ? "de" : "en";

i18n
  .use(initReactI18next)
  .init({
    lng: initial,
    fallbackLng,
    resources: { de: { common: de }, en: { common: en } },
    defaultNS: "common",
    interpolation: { escapeValue: false }
  });

/** keep <html lang="…"> in sync */
if (typeof document !== "undefined") {
  document.documentElement.lang = i18n.language;
}

i18n.on("languageChanged", (lng) => {
  if (typeof window !== "undefined") localStorage.setItem(STORAGE_KEY, lng);
  if (typeof document !== "undefined") document.documentElement.lang = lng;
});

export default i18n;
